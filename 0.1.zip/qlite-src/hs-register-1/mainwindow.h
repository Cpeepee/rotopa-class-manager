#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_btn_register_clear_clicked();

    void on_btn_register_insert_clicked();

    void on_hs_register_triggered();

    void on_hs_edit_triggered();

    void on_btn_hs_search_for_edit_clicked();

    void on_btn_register_avatar_clicked();

    void on_btn_login_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
