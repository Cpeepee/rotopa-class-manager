//defualt include
#include "mainwindow.h"
#include "ui_mainwindow.h"
//SQL include
#include <QtSql/QSql>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
//string include
#include <QString>
//QMessageBox include
#include <QMessageBox>
// Date include
#include <QDateTime>

//image include
#include <QPixmap>
#include <QFileDialog>

//search edit varibels regestration
QString family="";
QString name="";
QString code="";
QString *editVar;
//QString *editVar2;
QString editParameter="";
QString avatar_url="";

//database dynamic variables for Disable Status on(RegistraionTitles)
QString dbDynamic_disable_status_Text = "false"; // or use '0'

//check code user at search to edit user registeration
bool stats_check_code_user = false;

// for search edit registration name and family variabels
bool edit_search_name_and_family = false;
bool edit_search_code_and_name_and_family = false;
bool edit_search_code_and_name = false;
bool edit_search_code_and_family = false;
QString tmp1,tmp2,tmp3 = "";


//url defualt avatar for registration from adminconfig
QString defualt_avatar="";


MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFixedSize(QSize(841, 640));

    //Login admin page
    ui->menubar->setDisabled(true); // or hide this

    //set postions ..
    ui->groupBox_login->setGeometry(240,130,361,281);
    ui->groupBox_hs_search_for_edit->setGeometry(200,130,460,331);
    ui->groupBox_hs_register->setGeometry(10,10,821,581);
    //----------

    ui->groupBox_hs_register->hide();   ui->groupBox_hs_search_for_edit->hide();

    //Please don't remove this code.
    QLabel *poweredbyqt_and_opensource = new QLabel(this);
    poweredbyqt_and_opensource->setText("Powered by Qt | GPL v3 open-source license");
    ui->statusbar->addWidget(poweredbyqt_and_opensource);
    //------------------------------

//    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE"); //QMYSQL
//    db.setHostName("localhost");
//    db.setDatabaseName("hsfffwafwafwa");
//    db.setUserName("dwafwfa");
//    db.setPassword("");
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("./database/hs.db");
    if(db.open())
    {
        ui->groupBox_hs_register->hide();   ui->groupBox_hs_search_for_edit->hide();
    }
    else
        QMessageBox ::critical (this,"خطا" ,"اتصال به پایگاه داده انجام نشد.");

}
MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_btn_register_clear_clicked()
{
    if(ui->btn_register_clear->text() == "انصراف")
    {
        ui->groupBox_hs_register->hide();
        ui->groupBox_hs_search_for_edit->hide();
        ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
        ui->txt_register_0->setToolTip("");  ui->txt_register_1->setToolTip("");  ui->txt_register_2->setToolTip("");
        ui->groupBox_hs_register->setTitle("فرم ثبت نام عضو جدید در حسینیه");
        ui->btn_register_insert->setText("ثبت"); //ui->btn_register_clear->setText("تنظیم مجدد");
        ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg
    }
    else
    {
        QMessageBox::critical(this,"","error code 1");
        //if want to back and make button clear/reset everything from form . use down code and idcode(codr1)
       // ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg
    }

}

void MainWindow::on_btn_register_insert_clicked()
{

    if(ui->txt_register_0->text() == "" || (ui->txt_register_1->text() == "" && ui->txt_register_2->text()==""))
    {
        QMessageBox ::warning(this,"خطا" ," فیلد ها اصلی خالی است‌‌ !!");//یکی از
    }
    else
    {
        if(ui->groupBox_hs_register->title()== "فرم ویرایش اعضای حسینیه")
        {
            if(edit_search_name_and_family == true)
            {
                QSqlQuery q_Hs_Modify_userxx("UPDATE registration SET p0='"+ui->txt_register_0->text()+"',p1='"+ui->txt_register_1->text()+"',p3='"+ui->txt_register_3->text()+"',p4='"+ui->txt_register_4->text()+"',p5='"+ui->txt_register_5->text()+"',p6='"+ui->txt_register_6->text()+"',p7='"+ui->txt_register_7->text()+"',p8='"+ui->txt_register_8->text()+"',p9='"+ui->txt_register_9->text()+"',p10='"+ui->txt_register_10->text()+"',p11='"+ui->txt_register_11->text()+"',p12='"+ui->txt_register_12->text()+"',p13='"+ui->txt_register_13->text()+"',p14='"+ui->txt_register_14->text()+"',p15='"+ui->txt_register_15->text()+"',p16='"+ui->txt_register_16->text()+"',p17='"+ui->txt_register_17->text()+"',p18='"+ui->txt_register_18->text()+"',p19='"+ui->txt_register_19->text()+"',p20='"+ui->txt_register_20->text()+"',p21='"+ui->txt_register_21->text()+"',p22='"+ui->txt_register_22->text()+"',p23='"+ui->txt_register_23->text()+"',p24='"+ui->txt_register_24->text()+"',p25='"+ui->txt_register_24->text()+"',p26='"+ui->txt_register_26->text()+"',p27='"+ui->txt_register_27->text()+"',p28='"+ui->txt_register_28->text()+"',p29='"+ui->txt_register_29->text()+"',p30='"+avatar_url+"' WHERE p1='"+tmp1+"' AND p2='"+tmp2+"';");
                QMessageBox::information(this,"توجه",
                                         "ویرایش کاربر "+ui->txt_register_1->text() +
                                         "  "
                                         + ui->txt_register_2->text()+
                                         "  "+ui->txt_register_0->text()+"  "
                                         +"با موفقیت انجام شد.");
                ui->groupBox_hs_register->hide();
                //remove everything from form registeration
                ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg
                ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
                ui->txt_register_0->setToolTip(""); ui->txt_register_1->setToolTip(""); ui->txt_register_2->setToolTip("");
                family=""; name=""; code="";
                editParameter=""; avatar_url="";
                edit_search_name_and_family = false;
                edit_search_code_and_name_and_family = false;
                edit_search_code_and_name = false;
                edit_search_code_and_family = false;
                stats_check_code_user= false;
                tmp1="";tmp2="";tmp3="";
                //back to main window slide ..
                ui->groupBox_hs_register->hide();
                ui->groupBox_hs_search_for_edit->hide();
                ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
                ui->txt_register_0->setToolTip("");  ui->txt_register_1->setToolTip("");  ui->txt_register_2->setToolTip("");
                ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg

            }
            else if(edit_search_code_and_name_and_family == true)
            {
                QSqlQuery q_Hs_Modify_userxx("UPDATE registration SET p0='"+ui->txt_register_0->text()+"',p1='"+ui->txt_register_1->text()+"',p3='"+ui->txt_register_3->text()+"',p4='"+ui->txt_register_4->text()+"',p5='"+ui->txt_register_5->text()+"',p6='"+ui->txt_register_6->text()+"',p7='"+ui->txt_register_7->text()+"',p8='"+ui->txt_register_8->text()+"',p9='"+ui->txt_register_9->text()+"',p10='"+ui->txt_register_10->text()+"',p11='"+ui->txt_register_11->text()+"',p12='"+ui->txt_register_12->text()+"',p13='"+ui->txt_register_13->text()+"',p14='"+ui->txt_register_14->text()+"',p15='"+ui->txt_register_15->text()+"',p16='"+ui->txt_register_16->text()+"',p17='"+ui->txt_register_17->text()+"',p18='"+ui->txt_register_18->text()+"',p19='"+ui->txt_register_19->text()+"',p20='"+ui->txt_register_20->text()+"',p21='"+ui->txt_register_21->text()+"',p22='"+ui->txt_register_22->text()+"',p23='"+ui->txt_register_23->text()+"',p24='"+ui->txt_register_24->text()+"',p25='"+ui->txt_register_24->text()+"',p26='"+ui->txt_register_26->text()+"',p27='"+ui->txt_register_27->text()+"',p28='"+ui->txt_register_28->text()+"',p29='"+ui->txt_register_29->text()+"',p30='"+avatar_url+"' WHERE p1='"+tmp1+"' AND p2='"+tmp2+"' AND p3='"+tmp3+"';");
                QMessageBox::information(this,"توجه",
                                         "ویرایش کاربر "+ui->txt_register_1->text() +
                                         "  "
                                         + ui->txt_register_2->text()+
                                         "  "+ui->txt_register_0->text()+"  "
                                         +"با موفقیت انجام شد.");
                ui->groupBox_hs_register->hide();
                //remove everything from form registeration
                ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg
                ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
                ui->txt_register_0->setToolTip(""); ui->txt_register_1->setToolTip(""); ui->txt_register_2->setToolTip("");
                family=""; name=""; code="";
                editParameter=""; avatar_url="";
                edit_search_name_and_family = false;
                edit_search_code_and_name_and_family = false;
                edit_search_code_and_name = false;
                edit_search_code_and_family = false;
                stats_check_code_user= false;
                tmp1="";tmp2="";tmp3="";
                //back to main window slide ..
                ui->groupBox_hs_register->hide();
                ui->groupBox_hs_search_for_edit->hide();
                ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
                ui->txt_register_0->setToolTip("");  ui->txt_register_1->setToolTip("");  ui->txt_register_2->setToolTip("");
                ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg


            }
            else if(edit_search_code_and_name==true)
            {                                                       //
                QSqlQuery q_Hs_Modify_userxx("UPDATE registration SET p0='"+ui->txt_register_0->text()+"',p1='"+ui->txt_register_1->text()+"',p3='"+ui->txt_register_3->text()+"',p4='"+ui->txt_register_4->text()+"',p5='"+ui->txt_register_5->text()+"',p6='"+ui->txt_register_6->text()+"',p7='"+ui->txt_register_7->text()+"',p8='"+ui->txt_register_8->text()+"',p9='"+ui->txt_register_9->text()+"',p10='"+ui->txt_register_10->text()+"',p11='"+ui->txt_register_11->text()+"',p12='"+ui->txt_register_12->text()+"',p13='"+ui->txt_register_13->text()+"',p14='"+ui->txt_register_14->text()+"',p15='"+ui->txt_register_15->text()+"',p16='"+ui->txt_register_16->text()+"',p17='"+ui->txt_register_17->text()+"',p18='"+ui->txt_register_18->text()+"',p19='"+ui->txt_register_19->text()+"',p20='"+ui->txt_register_20->text()+"',p21='"+ui->txt_register_21->text()+"',p22='"+ui->txt_register_22->text()+"',p23='"+ui->txt_register_23->text()+"',p24='"+ui->txt_register_24->text()+"',p25='"+ui->txt_register_24->text()+"',p26='"+ui->txt_register_26->text()+"',p27='"+ui->txt_register_27->text()+"',p28='"+ui->txt_register_28->text()+"',p29='"+ui->txt_register_29->text()+"',p30='"+avatar_url+"' WHERE p0='"+tmp1+"' AND p1='"+tmp2+"';");
                QMessageBox::information(this,"توجه",
                                         "ویرایش کاربر "+ui->txt_register_1->text() +
                                         "  "
                                         + ui->txt_register_2->text()+
                                         "  "+ui->txt_register_0->text()+"  "
                                         +"با موفقیت انجام شد.");
                ui->groupBox_hs_register->hide();
                //remove everything from form registeration
                ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg
                ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
                ui->txt_register_0->setToolTip(""); ui->txt_register_1->setToolTip(""); ui->txt_register_2->setToolTip("");
                family=""; name=""; code="";
                editParameter=""; avatar_url="";
                edit_search_name_and_family = false;
                edit_search_code_and_name_and_family = false;
                edit_search_code_and_name = false;
                edit_search_code_and_family = false;
                stats_check_code_user= false;
                tmp1="";tmp2="";tmp3="";
                //back to main window slide ..
                ui->groupBox_hs_register->hide();
                ui->groupBox_hs_search_for_edit->hide();
                ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
                ui->txt_register_0->setToolTip("");  ui->txt_register_1->setToolTip("");  ui->txt_register_2->setToolTip("");
                ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg

            }
            else if(edit_search_code_and_family==true)
            {

                QSqlQuery q_Hs_Modify_userxx("UPDATE registration SET p0='"+ui->txt_register_0->text()+"',p1='"+ui->txt_register_1->text()+"',p3='"+ui->txt_register_3->text()+"',p4='"+ui->txt_register_4->text()+"',p5='"+ui->txt_register_5->text()+"',p6='"+ui->txt_register_6->text()+"',p7='"+ui->txt_register_7->text()+"',p8='"+ui->txt_register_8->text()+"',p9='"+ui->txt_register_9->text()+"',p10='"+ui->txt_register_10->text()+"',p11='"+ui->txt_register_11->text()+"',p12='"+ui->txt_register_12->text()+"',p13='"+ui->txt_register_13->text()+"',p14='"+ui->txt_register_14->text()+"',p15='"+ui->txt_register_15->text()+"',p16='"+ui->txt_register_16->text()+"',p17='"+ui->txt_register_17->text()+"',p18='"+ui->txt_register_18->text()+"',p19='"+ui->txt_register_19->text()+"',p20='"+ui->txt_register_20->text()+"',p21='"+ui->txt_register_21->text()+"',p22='"+ui->txt_register_22->text()+"',p23='"+ui->txt_register_23->text()+"',p24='"+ui->txt_register_24->text()+"',p25='"+ui->txt_register_24->text()+"',p26='"+ui->txt_register_26->text()+"',p27='"+ui->txt_register_27->text()+"',p28='"+ui->txt_register_28->text()+"',p29='"+ui->txt_register_29->text()+"',p30='"+avatar_url+"' WHERE p0='"+tmp1+"' AND p2='"+tmp2+"';");
                QMessageBox::information(this,"توجه",
                                         "ویرایش کاربر "+ui->txt_register_1->text() +
                                         "  "
                                         + ui->txt_register_2->text()+
                                         "  "+ui->txt_register_0->text()+"  "
                                         +"با موفقیت انجام شد.");
                ui->groupBox_hs_register->hide();
                //remove everything from form registeration
                ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg
                ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
                ui->txt_register_0->setToolTip(""); ui->txt_register_1->setToolTip(""); ui->txt_register_2->setToolTip("");
                family=""; name=""; code="";
                editParameter=""; avatar_url="";
                edit_search_name_and_family = false;
                edit_search_code_and_name_and_family = false;
                edit_search_code_and_name = false;
                edit_search_code_and_family = false;
                stats_check_code_user= false;
                tmp1="";tmp2="";tmp3="";
                //back to main window slide ..
                ui->groupBox_hs_register->hide();
                ui->groupBox_hs_search_for_edit->hide();
                ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
                ui->txt_register_0->setToolTip("");  ui->txt_register_1->setToolTip("");  ui->txt_register_2->setToolTip("");
                ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg


            }
            else
            {
                QSqlQuery q_Hs_Modify_userxx("UPDATE registration SET p0='"+ui->txt_register_0->text()+"',p1='"+ui->txt_register_1->text()+"',p2='"+ui->txt_register_2->text()+"',p3='"+ui->txt_register_3->text()+"',p4='"+ui->txt_register_4->text()+"',p5='"+ui->txt_register_5->text()+"',p6='"+ui->txt_register_6->text()+"',p7='"+ui->txt_register_7->text()+"',p8='"+ui->txt_register_8->text()+"',p9='"+ui->txt_register_9->text()+"',p10='"+ui->txt_register_10->text()+"',p11='"+ui->txt_register_11->text()+"',p12='"+ui->txt_register_12->text()+"',p13='"+ui->txt_register_13->text()+"',p14='"+ui->txt_register_14->text()+"',p15='"+ui->txt_register_15->text()+"',p16='"+ui->txt_register_16->text()+"',p17='"+ui->txt_register_17->text()+"',p18='"+ui->txt_register_18->text()+"',p19='"+ui->txt_register_19->text()+"',p20='"+ui->txt_register_20->text()+"',p21='"+ui->txt_register_21->text()+"',p22='"+ui->txt_register_22->text()+"',p23='"+ui->txt_register_23->text()+"',p24='"+ui->txt_register_24->text()+"',p25='"+ui->txt_register_24->text()+"',p26='"+ui->txt_register_26->text()+"',p27='"+ui->txt_register_27->text()+"',p28='"+ui->txt_register_28->text()+"',p29='"+ui->txt_register_29->text()+"',p30='"+avatar_url+"' WHERE "+editParameter+"='"+*editVar+"';");
                QMessageBox::information(this,"توجه",
                                         "ویرایش کاربر "+ui->txt_register_1->text() +
                                         "  "
                                         + ui->txt_register_2->text()+
                                         "  "+ui->txt_register_0->text()+"  "
                                         +"با موفقیت انجام شد.");
                ui->groupBox_hs_register->hide();
                //ui->groupBox_hs_search_for_edit->hide();
                //remove everything from form registeration
                ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg
                ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
                ui->txt_register_0->setToolTip(""); ui->txt_register_1->setToolTip(""); ui->txt_register_2->setToolTip("");
                family=""; name=""; code="";
                editParameter=""; avatar_url="";
                edit_search_name_and_family = false;
                edit_search_code_and_name_and_family = false;
                edit_search_code_and_name = false;
                edit_search_code_and_family = false;
                stats_check_code_user= false;
                tmp1="";tmp2="";tmp3="";
                //back to main window slide ..
                ui->groupBox_hs_register->hide();
                ui->groupBox_hs_search_for_edit->hide();
                ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
                ui->txt_register_0->setToolTip("");  ui->txt_register_1->setToolTip("");  ui->txt_register_2->setToolTip("");
                ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg

            }
        }
        else
        {
            QSqlQuery q_Hs_Register_user("INSERT INTO registration (p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23,p24,p25,p26,p27,p28,p29,p30) VALUES ('"+ui->txt_register_0->text()+"','"+ui->txt_register_1->text()+"','"+ui->txt_register_2->text()+"','"+ui->txt_register_3->text()+"','"+ui->txt_register_4->text()+"','"+ui->txt_register_5->text()+"','"+ui->txt_register_6->text()+"','"+ui->txt_register_7->text()+"','"+ui->txt_register_8->text()+"','"+ui->txt_register_9->text()+"','"+ui->txt_register_10->text()+"','"+ui->txt_register_11->text()+"','"+ui->txt_register_12->text()+"','"+ui->txt_register_13->text()+"','"+ui->txt_register_14->text()+"','"+ui->txt_register_15->text()+"','"+ui->txt_register_16->text()+"','"+ui->txt_register_17->text()+"','"+ui->txt_register_18->text()+"','"+ui->txt_register_19->text()+"','"+ui->txt_register_20->text()+"','"+ui->txt_register_21->text()+"','"+ui->txt_register_22->text()+"','"+ui->txt_register_23->text()+"','"+ui->txt_register_24->text()+"','"+ui->txt_register_25->text()+"','"+ui->txt_register_26->text()+"','"+ui->txt_register_27->text()+"','"+ui->txt_register_28->text()+"','"+ui->txt_register_29->text()+"','"+avatar_url+"');");
            //show message
            QMessageBox::information(this,"",
                                     "کاربر با مشخصات :\n"
                                     "نام‌: "+ui->txt_register_1->text()+
                                     "\nنام خانوادگی :"+ui->txt_register_2->text()+
                                     "\n کدملی: "+ui->txt_register_0->text()+ "\n"
                                     "با موفیقت ساخته شد.");

            //back to main window slide ..
            ui->groupBox_hs_register->hide();
            ui->groupBox_hs_search_for_edit->hide();
            ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
            ui->txt_register_0->setToolTip("");  ui->txt_register_1->setToolTip("");  ui->txt_register_2->setToolTip("");
            ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg


        }
    }
}

void MainWindow::on_hs_register_triggered()
{
    ui->groupBox_hs_search_for_edit->hide();
    ui->groupBox_hs_register->show();
    ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
    ui->txt_register_0->setToolTip(""); ui->txt_register_1->setToolTip(""); ui->txt_register_2->setToolTip("");
    ui->groupBox_hs_register->setTitle("فرم ثبت نام عضو جدید در حسینیه");
    ui->btn_register_insert->setText("ثبت");
    //if want to back and make button clear/reset everything from form idcode(codr1)
            //ui->btn_register_clear->setText("تنظیم مجدد");
    ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg
    QSqlQuery q_Hs_Load_Title("SELECT * FROM registrationTitles");
    while (q_Hs_Load_Title.next())
    {
        ui->lbl_register_t0->setText(q_Hs_Load_Title.value("t0").toString()); ui->lbl_register_t1->setText(q_Hs_Load_Title.value("t1").toString()); ui->lbl_register_t2->setText(q_Hs_Load_Title.value("t2").toString()); ui->lbl_register_t3->setText(q_Hs_Load_Title.value("t3").toString()); ui->lbl_register_t4->setText(q_Hs_Load_Title.value("t4").toString());                ui->lbl_register_t5->setText(q_Hs_Load_Title.value("t5").toString()); ui->lbl_register_t6->setText(q_Hs_Load_Title.value("t6").toString());               ui->lbl_register_t7->setText(q_Hs_Load_Title.value("t7").toString());  ui->lbl_register_t8->setText(q_Hs_Load_Title.value("t8").toString());              ui->lbl_register_t9->setText(q_Hs_Load_Title.value("t9").toString()); ui->lbl_register_t10->setText(q_Hs_Load_Title.value("t10").toString());                ui->lbl_register_t11->setText(q_Hs_Load_Title.value("t11").toString()); ui->lbl_register_t12->setText(q_Hs_Load_Title.value("t12").toString()); ui->lbl_register_t13->setText(q_Hs_Load_Title.value("t13").toString());                 ui->lbl_register_t14->setText(q_Hs_Load_Title.value("t14").toString()); ui->lbl_register_t15->setText(q_Hs_Load_Title.value("t15").toString());                ui->lbl_register_t16->setText(q_Hs_Load_Title.value("t16").toString());  ui->lbl_register_t17->setText(q_Hs_Load_Title.value("t17").toString()); ui->lbl_register_t18->setText(q_Hs_Load_Title.value("t18").toString());ui->lbl_register_t19->setText(q_Hs_Load_Title.value("t19").toString());ui->lbl_register_t20->setText(q_Hs_Load_Title.value("t20").toString());ui->lbl_register_t21->setText(q_Hs_Load_Title.value("t21").toString());ui->lbl_register_t22->setText(q_Hs_Load_Title.value("t22").toString());ui->lbl_register_t23->setText(q_Hs_Load_Title.value("t23").toString());ui->lbl_register_t24->setText(q_Hs_Load_Title.value("t24").toString());ui->lbl_register_t25->setText(q_Hs_Load_Title.value("t25").toString());ui->lbl_register_t26->setText(q_Hs_Load_Title.value("t26").toString()); ui->lbl_register_t27->setText(q_Hs_Load_Title.value("t27").toString());ui->lbl_register_t28->setText(q_Hs_Load_Title.value("t28").toString()); ui->lbl_register_t29->setText(q_Hs_Load_Title.value("t29").toString());
        //dbDynamic_disable_status_Text use this  disable_status
        const QString ds_number_0 = q_Hs_Load_Title.value("disable_status0").toString();
        if(ds_number_0 == dbDynamic_disable_status_Text) ui->txt_register_0->setDisabled(false); else ui->txt_register_0->setDisabled(true);
        const QString ds_number_1 = q_Hs_Load_Title.value("disable_status1").toString();
        if(ds_number_1 == dbDynamic_disable_status_Text) ui->txt_register_1->setDisabled(false); else ui->txt_register_1->setDisabled(true);
        const QString ds_number_2 = q_Hs_Load_Title.value("disable_status2").toString();
        if(ds_number_2 == dbDynamic_disable_status_Text) ui->txt_register_2->setDisabled(false); else ui->txt_register_2->setDisabled(true);
        const QString ds_number_3 = q_Hs_Load_Title.value("disable_status3").toString();
        if(ds_number_3 == dbDynamic_disable_status_Text) ui->txt_register_3->setDisabled(false); else ui->txt_register_3->setDisabled(true);
        const QString ds_number_4 = q_Hs_Load_Title.value("disable_status4").toString();
        if(ds_number_4 == dbDynamic_disable_status_Text) ui->txt_register_4->setDisabled(false); else ui->txt_register_4->setDisabled(true);
        const QString ds_number_5 = q_Hs_Load_Title.value("disable_status5").toString();
        if(ds_number_5 == dbDynamic_disable_status_Text) ui->txt_register_5->setDisabled(false); else ui->txt_register_5->setDisabled(true);
        const QString ds_number_6 = q_Hs_Load_Title.value("disable_status6").toString();
        if(ds_number_6 == dbDynamic_disable_status_Text) ui->txt_register_6->setDisabled(false); else ui->txt_register_6->setDisabled(true);
        const QString ds_number_7 = q_Hs_Load_Title.value("disable_status7").toString();
        if(ds_number_7 == dbDynamic_disable_status_Text) ui->txt_register_7->setDisabled(false); else ui->txt_register_7->setDisabled(true);
        const QString ds_number_8 = q_Hs_Load_Title.value("disable_status8").toString();
        if(ds_number_8 == dbDynamic_disable_status_Text) ui->txt_register_8->setDisabled(false); else ui->txt_register_8->setDisabled(true);
        const QString ds_number_9 = q_Hs_Load_Title.value("disable_status9").toString();
        if(ds_number_9 == dbDynamic_disable_status_Text) ui->txt_register_9->setDisabled(false); else ui->txt_register_9->setDisabled(true);
        const QString ds_number_10 = q_Hs_Load_Title.value("disable_status10").toString();
        if(ds_number_10 == dbDynamic_disable_status_Text) ui->txt_register_10->setDisabled(false); else ui->txt_register_10->setDisabled(true);
        const QString ds_number_11 = q_Hs_Load_Title.value("disable_status11").toString();
        if(ds_number_11 == dbDynamic_disable_status_Text) ui->txt_register_11->setDisabled(false); else ui->txt_register_11->setDisabled(true);
        const QString ds_number_12 = q_Hs_Load_Title.value("disable_status12").toString();
        if(ds_number_12 == dbDynamic_disable_status_Text) ui->txt_register_12->setDisabled(false); else ui->txt_register_12->setDisabled(true);
        const QString ds_number_13 = q_Hs_Load_Title.value("disable_status13").toString();
        if(ds_number_13 == dbDynamic_disable_status_Text) ui->txt_register_13->setDisabled(false); else ui->txt_register_13->setDisabled(true);
        const QString ds_number_14 = q_Hs_Load_Title.value("disable_status14").toString();
        if(ds_number_14 == dbDynamic_disable_status_Text) ui->txt_register_14->setDisabled(false); else ui->txt_register_14->setDisabled(true);
        const QString ds_number_15 = q_Hs_Load_Title.value("disable_status15").toString();
        if(ds_number_15 == dbDynamic_disable_status_Text) ui->txt_register_15->setDisabled(false); else ui->txt_register_15->setDisabled(true);
        const QString ds_number_16 = q_Hs_Load_Title.value("disable_status16").toString();
        if(ds_number_16 == dbDynamic_disable_status_Text) ui->txt_register_16->setDisabled(false); else ui->txt_register_16->setDisabled(true);
        const QString ds_number_17 = q_Hs_Load_Title.value("disable_status17").toString();
        if(ds_number_17 == dbDynamic_disable_status_Text) ui->txt_register_17->setDisabled(false); else ui->txt_register_17->setDisabled(true);
        const QString ds_number_18 = q_Hs_Load_Title.value("disable_status18").toString();
        if(ds_number_18 == dbDynamic_disable_status_Text) ui->txt_register_18->setDisabled(false); else ui->txt_register_18->setDisabled(true);
        const QString ds_number_19 = q_Hs_Load_Title.value("disable_status19").toString();
        if(ds_number_19 == dbDynamic_disable_status_Text) ui->txt_register_19->setDisabled(false); else ui->txt_register_19->setDisabled(true);
        const QString ds_number_20 = q_Hs_Load_Title.value("disable_status20").toString();
        if(ds_number_20 == dbDynamic_disable_status_Text) ui->txt_register_20->setDisabled(false); else ui->txt_register_20->setDisabled(true);
        const QString ds_number_21 = q_Hs_Load_Title.value("disable_status21").toString();
        if(ds_number_21 == dbDynamic_disable_status_Text) ui->txt_register_21->setDisabled(false); else ui->txt_register_21->setDisabled(true);
        const QString ds_number_22 = q_Hs_Load_Title.value("disable_status22").toString();
        if(ds_number_22 == dbDynamic_disable_status_Text) ui->txt_register_22->setDisabled(false); else ui->txt_register_22->setDisabled(true);
        const QString ds_number_23 = q_Hs_Load_Title.value("disable_status23").toString();
        if(ds_number_23 == dbDynamic_disable_status_Text) ui->txt_register_23->setDisabled(false); else ui->txt_register_23->setDisabled(true);
        const QString ds_number_24 = q_Hs_Load_Title.value("disable_status24").toString();
        if(ds_number_24 == dbDynamic_disable_status_Text) ui->txt_register_24->setDisabled(false); else ui->txt_register_24->setDisabled(true);
        const QString ds_number_25 = q_Hs_Load_Title.value("disable_status25").toString();
        if(ds_number_25 == dbDynamic_disable_status_Text) ui->txt_register_25->setDisabled(false); else ui->txt_register_25->setDisabled(true);
        const QString ds_number_26 = q_Hs_Load_Title.value("disable_status26").toString();
        if(ds_number_26 == dbDynamic_disable_status_Text) ui->txt_register_26->setDisabled(false); else ui->txt_register_26->setDisabled(true);
        const QString ds_number_27 = q_Hs_Load_Title.value("disable_status27").toString();
        if(ds_number_27 == dbDynamic_disable_status_Text) ui->txt_register_27->setDisabled(false); else ui->txt_register_27->setDisabled(true);
        const QString ds_number_28 = q_Hs_Load_Title.value("disable_status28").toString();
        if(ds_number_28 == dbDynamic_disable_status_Text) ui->txt_register_28->setDisabled(false); else ui->txt_register_28->setDisabled(true);
        const QString ds_number_29 = q_Hs_Load_Title.value("disable_status29").toString();
        if(ds_number_29 == dbDynamic_disable_status_Text) ui->txt_register_29->setDisabled(false); else ui->txt_register_29->setDisabled(true);
    }
    if(avatar_url == "")
    {
        QSqlQuery search_for_url_avatar_defualt("SELECT * FROM adminconfig;");
        //url
        while (search_for_url_avatar_defualt.next())
        {
            defualt_avatar = search_for_url_avatar_defualt.value("defualt_avatar").toString();
        }
        QPixmap pm(defualt_avatar); ui->lbl_register_avatar->setPixmap(defualt_avatar);
        ui->lbl_register_avatar->setScaledContents(true);
    }

}

void MainWindow::on_hs_edit_triggered()
{
    ui->groupBox_hs_register->hide();   ui->groupBox_hs_search_for_edit->show();
    ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg
    ui->txt_hs_search_for_edit_by_family->clear();  ui->txt_hs_search_for_edit_by_name->clear();  ui->txt_hs_search_for_edit_by_code->clear();
    ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false);  ui->txt_register_2->setDisabled(false);
    ui->txt_register_0->setToolTip(""); ui->txt_register_1->setToolTip("");  ui->txt_register_2->setToolTip("");
}

void MainWindow::on_btn_hs_search_for_edit_clicked()
{
    ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false); ui->txt_register_2->setDisabled(false);
    ui->txt_register_0->setToolTip(""); ui->txt_register_1->setToolTip(""); ui->txt_register_2->setToolTip("");
    if(ui->txt_hs_search_for_edit_by_code->text() == "" && ui->txt_hs_search_for_edit_by_name->text() == "" && ui->txt_hs_search_for_edit_by_family->text() == "")
    {
        QMessageBox::warning(this,"خطا","باید حداقل یکی از فیلدها جهت جستجو پرشود\n جهت دقت بیشتر در جستجو ، از فیلد های بیشتری استفاده کنید"); //
    }
    else if(ui->txt_hs_search_for_edit_by_code->text() == "" && ui->txt_hs_search_for_edit_by_name->text() == "" && ui->txt_hs_search_for_edit_by_family->text() != "")
    {
        family = ui->txt_hs_search_for_edit_by_family->text();
        ui->groupBox_hs_search_for_edit->hide();
        editVar = &family;
        editParameter = "p2";
        ui->txt_register_2->setDisabled(true);
        ui->txt_register_2->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو > کد ملی ");
        ui->groupBox_hs_register->show();
        ui->groupBox_hs_register->setTitle("فرم ویرایش اعضای حسینیه");
        ui->btn_register_insert->setText("ویرایش");
        ui->btn_register_clear->setText("انصراف");

        QSqlQuery q_Hs_Load_Title("SELECT * FROM registrationTitles");
        while (q_Hs_Load_Title.next())
        {
            ui->lbl_register_t0->setText(q_Hs_Load_Title.value("t0").toString()); ui->lbl_register_t1->setText(q_Hs_Load_Title.value("t1").toString()); ui->lbl_register_t2->setText(q_Hs_Load_Title.value("t2").toString()); ui->lbl_register_t3->setText(q_Hs_Load_Title.value("t3").toString()); ui->lbl_register_t4->setText(q_Hs_Load_Title.value("t4").toString());                ui->lbl_register_t5->setText(q_Hs_Load_Title.value("t5").toString()); ui->lbl_register_t6->setText(q_Hs_Load_Title.value("t6").toString());               ui->lbl_register_t7->setText(q_Hs_Load_Title.value("t7").toString());  ui->lbl_register_t8->setText(q_Hs_Load_Title.value("t8").toString());              ui->lbl_register_t9->setText(q_Hs_Load_Title.value("t9").toString()); ui->lbl_register_t10->setText(q_Hs_Load_Title.value("t10").toString());                ui->lbl_register_t11->setText(q_Hs_Load_Title.value("t11").toString()); ui->lbl_register_t12->setText(q_Hs_Load_Title.value("t12").toString()); ui->lbl_register_t13->setText(q_Hs_Load_Title.value("t13").toString());                 ui->lbl_register_t14->setText(q_Hs_Load_Title.value("t14").toString()); ui->lbl_register_t15->setText(q_Hs_Load_Title.value("t15").toString());                ui->lbl_register_t16->setText(q_Hs_Load_Title.value("t16").toString());  ui->lbl_register_t17->setText(q_Hs_Load_Title.value("t17").toString()); ui->lbl_register_t18->setText(q_Hs_Load_Title.value("t18").toString());ui->lbl_register_t19->setText(q_Hs_Load_Title.value("t19").toString());ui->lbl_register_t20->setText(q_Hs_Load_Title.value("t20").toString());ui->lbl_register_t21->setText(q_Hs_Load_Title.value("t21").toString());ui->lbl_register_t22->setText(q_Hs_Load_Title.value("t22").toString());ui->lbl_register_t23->setText(q_Hs_Load_Title.value("t23").toString());ui->lbl_register_t24->setText(q_Hs_Load_Title.value("t24").toString());ui->lbl_register_t25->setText(q_Hs_Load_Title.value("t25").toString());ui->lbl_register_t26->setText(q_Hs_Load_Title.value("t26").toString()); ui->lbl_register_t27->setText(q_Hs_Load_Title.value("t27").toString());ui->lbl_register_t28->setText(q_Hs_Load_Title.value("t28").toString()); ui->lbl_register_t29->setText(q_Hs_Load_Title.value("t29").toString());
        }


        QSqlQuery q_Hs_search_for_edit_by_family("SELECT * FROM registration WHERE p2='"+ui->txt_hs_search_for_edit_by_family->text()+"'");
        while (q_Hs_search_for_edit_by_family.next())
        {
            ui->txt_register_0->setText(q_Hs_search_for_edit_by_family.value("p0").toString());     ui->txt_register_1->setText(q_Hs_search_for_edit_by_family.value("p1").toString());
            ui->txt_register_2->setText(q_Hs_search_for_edit_by_family.value("p2").toString());     ui->txt_register_3->setText(q_Hs_search_for_edit_by_family.value("p3").toString());
            ui->txt_register_4->setText(q_Hs_search_for_edit_by_family.value("p4").toString());     ui->txt_register_5->setText(q_Hs_search_for_edit_by_family.value("p5").toString());
            ui->txt_register_6->setText(q_Hs_search_for_edit_by_family.value("p6").toString());     ui->txt_register_7->setText(q_Hs_search_for_edit_by_family.value("p7").toString());
            ui->txt_register_8->setText(q_Hs_search_for_edit_by_family.value("p8").toString());     ui->txt_register_9->setText(q_Hs_search_for_edit_by_family.value("p9").toString());
            ui->txt_register_10->setText(q_Hs_search_for_edit_by_family.value("p10").toString());   ui->txt_register_11->setText(q_Hs_search_for_edit_by_family.value("p11").toString());
            ui->txt_register_12->setText(q_Hs_search_for_edit_by_family.value("p12").toString());   ui->txt_register_13->setText(q_Hs_search_for_edit_by_family.value("p13").toString());
            ui->txt_register_14->setText(q_Hs_search_for_edit_by_family.value("p14").toString());   ui->txt_register_15->setText(q_Hs_search_for_edit_by_family.value("p15").toString());
            ui->txt_register_16->setText(q_Hs_search_for_edit_by_family.value("p16").toString());   ui->txt_register_17->setText(q_Hs_search_for_edit_by_family.value("p17").toString());
            ui->txt_register_18->setText(q_Hs_search_for_edit_by_family.value("p18").toString());   ui->txt_register_19->setText(q_Hs_search_for_edit_by_family.value("p19").toString());
            ui->txt_register_20->setText(q_Hs_search_for_edit_by_family.value("p20").toString());   ui->txt_register_21->setText(q_Hs_search_for_edit_by_family.value("p21").toString());
            ui->txt_register_22->setText(q_Hs_search_for_edit_by_family.value("p22").toString());   ui->txt_register_23->setText(q_Hs_search_for_edit_by_family.value("p23").toString());
            ui->txt_register_24->setText(q_Hs_search_for_edit_by_family.value("p24").toString());   ui->txt_register_25->setText(q_Hs_search_for_edit_by_family.value("p25").toString());
            ui->txt_register_26->setText(q_Hs_search_for_edit_by_family.value("p26").toString());   ui->txt_register_27->setText(q_Hs_search_for_edit_by_family.value("p27").toString());
            ui->txt_register_28->setText(q_Hs_search_for_edit_by_family.value("p28").toString());   ui->txt_register_29->setText(q_Hs_search_for_edit_by_family.value("p29").toString());
            avatar_url = q_Hs_search_for_edit_by_family.value("p30").toString();
            QPixmap avatar_from_edit(avatar_url); ui->lbl_register_avatar->setPixmap(avatar_url); ui->lbl_register_avatar->setScaledContents(true);

        }
        ui->txt_hs_search_for_edit_by_code->clear();    ui->txt_hs_search_for_edit_by_name->clear();    ui->txt_hs_search_for_edit_by_family->clear();
        if(ui->txt_register_0->text()=="" && ui->txt_register_1->text() =="" &&ui->txt_register_2->text()=="")
        {
            ui->groupBox_hs_register->hide();
            ui->groupBox_hs_search_for_edit->show();
            ui->txt_hs_search_for_edit_by_code->clear();    ui->txt_hs_search_for_edit_by_name->clear();    ui->txt_hs_search_for_edit_by_family->clear();
            QMessageBox :: warning(this,"خطا","کاربری با چنین نام خانوادگی یافت نشد\nجهت دقت بیشتر در جستجو ، از فیلد های بیشتری استفاده کنید");
        }
    }
    else if(ui->txt_hs_search_for_edit_by_code->text() == "" && ui->txt_hs_search_for_edit_by_name->text() != "" && ui->txt_hs_search_for_edit_by_family->text() == "")
    {

        name = ui->txt_hs_search_for_edit_by_name->text();
        ui->groupBox_hs_search_for_edit->hide();
        editVar = &name;
        editParameter = "p1";
        ui->txt_register_0->setDisabled(false);
        ui->txt_register_0->setToolTip("");
        ui->txt_register_1->setDisabled(true);
        ui->txt_register_1->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو > کد ملی ");
        ui->groupBox_hs_register->show();
        ui->groupBox_hs_register->setTitle("فرم ویرایش اعضای حسینیه");
        ui->btn_register_insert->setText("ویرایش");
        ui->btn_register_clear->setText("انصراف");

        QSqlQuery q_Hs_Load_Title("SELECT * FROM registrationTitles");
        while (q_Hs_Load_Title.next())
        {
            ui->lbl_register_t0->setText(q_Hs_Load_Title.value("t0").toString()); ui->lbl_register_t1->setText(q_Hs_Load_Title.value("t1").toString()); ui->lbl_register_t2->setText(q_Hs_Load_Title.value("t2").toString()); ui->lbl_register_t3->setText(q_Hs_Load_Title.value("t3").toString()); ui->lbl_register_t4->setText(q_Hs_Load_Title.value("t4").toString());                ui->lbl_register_t5->setText(q_Hs_Load_Title.value("t5").toString()); ui->lbl_register_t6->setText(q_Hs_Load_Title.value("t6").toString());               ui->lbl_register_t7->setText(q_Hs_Load_Title.value("t7").toString());  ui->lbl_register_t8->setText(q_Hs_Load_Title.value("t8").toString());              ui->lbl_register_t9->setText(q_Hs_Load_Title.value("t9").toString()); ui->lbl_register_t10->setText(q_Hs_Load_Title.value("t10").toString());                ui->lbl_register_t11->setText(q_Hs_Load_Title.value("t11").toString()); ui->lbl_register_t12->setText(q_Hs_Load_Title.value("t12").toString()); ui->lbl_register_t13->setText(q_Hs_Load_Title.value("t13").toString());                 ui->lbl_register_t14->setText(q_Hs_Load_Title.value("t14").toString()); ui->lbl_register_t15->setText(q_Hs_Load_Title.value("t15").toString());                ui->lbl_register_t16->setText(q_Hs_Load_Title.value("t16").toString());  ui->lbl_register_t17->setText(q_Hs_Load_Title.value("t17").toString()); ui->lbl_register_t18->setText(q_Hs_Load_Title.value("t18").toString());ui->lbl_register_t19->setText(q_Hs_Load_Title.value("t19").toString());ui->lbl_register_t20->setText(q_Hs_Load_Title.value("t20").toString());ui->lbl_register_t21->setText(q_Hs_Load_Title.value("t21").toString());ui->lbl_register_t22->setText(q_Hs_Load_Title.value("t22").toString());ui->lbl_register_t23->setText(q_Hs_Load_Title.value("t23").toString());ui->lbl_register_t24->setText(q_Hs_Load_Title.value("t24").toString());ui->lbl_register_t25->setText(q_Hs_Load_Title.value("t25").toString());ui->lbl_register_t26->setText(q_Hs_Load_Title.value("t26").toString()); ui->lbl_register_t27->setText(q_Hs_Load_Title.value("t27").toString());ui->lbl_register_t28->setText(q_Hs_Load_Title.value("t28").toString()); ui->lbl_register_t29->setText(q_Hs_Load_Title.value("t29").toString());
        }
        QSqlQuery q_Hs_search_for_edit_by_name("SELECT * FROM registration WHERE p1='"+ui->txt_hs_search_for_edit_by_name->text()+"'");
        while (q_Hs_search_for_edit_by_name.next())
        {
            ui->txt_register_0->setText(q_Hs_search_for_edit_by_name.value("p0").toString());   ui->txt_register_1->setText(q_Hs_search_for_edit_by_name.value("p1").toString());
            ui->txt_register_2->setText(q_Hs_search_for_edit_by_name.value("p2").toString());   ui->txt_register_3->setText(q_Hs_search_for_edit_by_name.value("p3").toString());
            ui->txt_register_4->setText(q_Hs_search_for_edit_by_name.value("p4").toString());   ui->txt_register_5->setText(q_Hs_search_for_edit_by_name.value("p5").toString());
            ui->txt_register_6->setText(q_Hs_search_for_edit_by_name.value("p6").toString());   ui->txt_register_7->setText(q_Hs_search_for_edit_by_name.value("p7").toString());
            ui->txt_register_8->setText(q_Hs_search_for_edit_by_name.value("p8").toString());   ui->txt_register_9->setText(q_Hs_search_for_edit_by_name.value("p9").toString());
            ui->txt_register_10->setText(q_Hs_search_for_edit_by_name.value("p10").toString()); ui->txt_register_11->setText(q_Hs_search_for_edit_by_name.value("p11").toString());
            ui->txt_register_12->setText(q_Hs_search_for_edit_by_name.value("p12").toString()); ui->txt_register_13->setText(q_Hs_search_for_edit_by_name.value("p13").toString());
            ui->txt_register_14->setText(q_Hs_search_for_edit_by_name.value("p14").toString()); ui->txt_register_15->setText(q_Hs_search_for_edit_by_name.value("p15").toString());
            ui->txt_register_16->setText(q_Hs_search_for_edit_by_name.value("p16").toString()); ui->txt_register_17->setText(q_Hs_search_for_edit_by_name.value("p17").toString());
            ui->txt_register_18->setText(q_Hs_search_for_edit_by_name.value("p18").toString()); ui->txt_register_19->setText(q_Hs_search_for_edit_by_name.value("p19").toString());
            ui->txt_register_20->setText(q_Hs_search_for_edit_by_name.value("p20").toString()); ui->txt_register_21->setText(q_Hs_search_for_edit_by_name.value("p21").toString());
            ui->txt_register_22->setText(q_Hs_search_for_edit_by_name.value("p22").toString()); ui->txt_register_23->setText(q_Hs_search_for_edit_by_name.value("p23").toString());
            ui->txt_register_24->setText(q_Hs_search_for_edit_by_name.value("p24").toString()); ui->txt_register_25->setText(q_Hs_search_for_edit_by_name.value("p25").toString());
            ui->txt_register_26->setText(q_Hs_search_for_edit_by_name.value("p26").toString()); ui->txt_register_27->setText(q_Hs_search_for_edit_by_name.value("p27").toString());
            ui->txt_register_28->setText(q_Hs_search_for_edit_by_name.value("p28").toString()); ui->txt_register_29->setText(q_Hs_search_for_edit_by_name.value("p29").toString());
            avatar_url = q_Hs_search_for_edit_by_name.value("p30").toString();
            QPixmap avatar_from_edit(avatar_url); // <- path to image file  "C:/Users/Patrick Wieland/Documents/Kochen/bento.jpg"
            ui->lbl_register_avatar->setPixmap(avatar_url);
            ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg

        }
        ui->txt_hs_search_for_edit_by_code->clear();    ui->txt_hs_search_for_edit_by_name->clear();    ui->txt_hs_search_for_edit_by_family->clear();
        if(ui->txt_register_0->text()=="" && ui->txt_register_1->text() =="" &&ui->txt_register_2->text()=="")
        {
            ui->groupBox_hs_register->hide();
            ui->groupBox_hs_search_for_edit->show();
            ui->txt_hs_search_for_edit_by_code->clear();    ui->txt_hs_search_for_edit_by_name->clear();    ui->txt_hs_search_for_edit_by_family->clear();
            QMessageBox :: warning(this,"خطا"
                                       ,"کاربری با چنین نام یافت نشد \nجهت دقت بیشتر در جستجو ، از فیلد های بیشتری استفاده کنید");
        }

    }
    else if(ui->txt_hs_search_for_edit_by_code->text() != "" && ui->txt_hs_search_for_edit_by_name->text() == "" && ui->txt_hs_search_for_edit_by_family->text() == "")
    {
        code = ui->txt_hs_search_for_edit_by_code->text();
        ui->groupBox_hs_search_for_edit->hide();
        editVar = &code;
        editParameter = "p0";
        ui->txt_register_0->setDisabled(true);
        ui->txt_register_0->setToolTip("       نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید  \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو > نام یا نام خانوادگی");
        ui->groupBox_hs_register->show();
        ui->groupBox_hs_register->setTitle("فرم ویرایش اعضای حسینیه");
        ui->btn_register_insert->setText("ویرایش");
        ui->btn_register_clear->setText("انصراف");

        QSqlQuery q_Hs_Load_Title("SELECT * FROM registrationTitles");
        while (q_Hs_Load_Title.next())
        {
            ui->lbl_register_t0->setText(q_Hs_Load_Title.value("t0").toString()); ui->lbl_register_t1->setText(q_Hs_Load_Title.value("t1").toString()); ui->lbl_register_t2->setText(q_Hs_Load_Title.value("t2").toString()); ui->lbl_register_t3->setText(q_Hs_Load_Title.value("t3").toString()); ui->lbl_register_t4->setText(q_Hs_Load_Title.value("t4").toString());                ui->lbl_register_t5->setText(q_Hs_Load_Title.value("t5").toString()); ui->lbl_register_t6->setText(q_Hs_Load_Title.value("t6").toString());               ui->lbl_register_t7->setText(q_Hs_Load_Title.value("t7").toString());  ui->lbl_register_t8->setText(q_Hs_Load_Title.value("t8").toString());              ui->lbl_register_t9->setText(q_Hs_Load_Title.value("t9").toString()); ui->lbl_register_t10->setText(q_Hs_Load_Title.value("t10").toString());                ui->lbl_register_t11->setText(q_Hs_Load_Title.value("t11").toString()); ui->lbl_register_t12->setText(q_Hs_Load_Title.value("t12").toString()); ui->lbl_register_t13->setText(q_Hs_Load_Title.value("t13").toString());                 ui->lbl_register_t14->setText(q_Hs_Load_Title.value("t14").toString()); ui->lbl_register_t15->setText(q_Hs_Load_Title.value("t15").toString());                ui->lbl_register_t16->setText(q_Hs_Load_Title.value("t16").toString());  ui->lbl_register_t17->setText(q_Hs_Load_Title.value("t17").toString()); ui->lbl_register_t18->setText(q_Hs_Load_Title.value("t18").toString());ui->lbl_register_t19->setText(q_Hs_Load_Title.value("t19").toString());ui->lbl_register_t20->setText(q_Hs_Load_Title.value("t20").toString());ui->lbl_register_t21->setText(q_Hs_Load_Title.value("t21").toString());ui->lbl_register_t22->setText(q_Hs_Load_Title.value("t22").toString());ui->lbl_register_t23->setText(q_Hs_Load_Title.value("t23").toString());ui->lbl_register_t24->setText(q_Hs_Load_Title.value("t24").toString());ui->lbl_register_t25->setText(q_Hs_Load_Title.value("t25").toString());ui->lbl_register_t26->setText(q_Hs_Load_Title.value("t26").toString()); ui->lbl_register_t27->setText(q_Hs_Load_Title.value("t27").toString());ui->lbl_register_t28->setText(q_Hs_Load_Title.value("t28").toString()); ui->lbl_register_t29->setText(q_Hs_Load_Title.value("t29").toString());
        }


        QSqlQuery q_Hs_search_for_edit_by_code("SELECT * FROM registration WHERE p0='"+ui->txt_hs_search_for_edit_by_code->text()+"'");
        while (q_Hs_search_for_edit_by_code.next())
        {
            ui->txt_register_0->setText(q_Hs_search_for_edit_by_code.value("p0").toString());   ui->txt_register_1->setText(q_Hs_search_for_edit_by_code.value("p1").toString());
            ui->txt_register_2->setText(q_Hs_search_for_edit_by_code.value("p2").toString());   ui->txt_register_3->setText(q_Hs_search_for_edit_by_code.value("p3").toString());
            ui->txt_register_4->setText(q_Hs_search_for_edit_by_code.value("p4").toString());   ui->txt_register_5->setText(q_Hs_search_for_edit_by_code.value("p5").toString());
            ui->txt_register_6->setText(q_Hs_search_for_edit_by_code.value("p6").toString());   ui->txt_register_7->setText(q_Hs_search_for_edit_by_code.value("p7").toString());
            ui->txt_register_8->setText(q_Hs_search_for_edit_by_code.value("p8").toString());   ui->txt_register_9->setText(q_Hs_search_for_edit_by_code.value("p9").toString());
            ui->txt_register_10->setText(q_Hs_search_for_edit_by_code.value("p10").toString()); ui->txt_register_11->setText(q_Hs_search_for_edit_by_code.value("p11").toString());
            ui->txt_register_12->setText(q_Hs_search_for_edit_by_code.value("p12").toString()); ui->txt_register_13->setText(q_Hs_search_for_edit_by_code.value("p13").toString());
            ui->txt_register_14->setText(q_Hs_search_for_edit_by_code.value("p14").toString()); ui->txt_register_15->setText(q_Hs_search_for_edit_by_code.value("p15").toString());
            ui->txt_register_16->setText(q_Hs_search_for_edit_by_code.value("p16").toString()); ui->txt_register_17->setText(q_Hs_search_for_edit_by_code.value("p17").toString());
            ui->txt_register_18->setText(q_Hs_search_for_edit_by_code.value("p18").toString()); ui->txt_register_19->setText(q_Hs_search_for_edit_by_code.value("p19").toString());
            ui->txt_register_20->setText(q_Hs_search_for_edit_by_code.value("p20").toString()); ui->txt_register_21->setText(q_Hs_search_for_edit_by_code.value("p21").toString());
            ui->txt_register_22->setText(q_Hs_search_for_edit_by_code.value("p22").toString()); ui->txt_register_23->setText(q_Hs_search_for_edit_by_code.value("p23").toString());
            ui->txt_register_24->setText(q_Hs_search_for_edit_by_code.value("p24").toString()); ui->txt_register_25->setText(q_Hs_search_for_edit_by_code.value("p25").toString());
            ui->txt_register_26->setText(q_Hs_search_for_edit_by_code.value("p26").toString()); ui->txt_register_27->setText(q_Hs_search_for_edit_by_code.value("p27").toString());
            ui->txt_register_28->setText(q_Hs_search_for_edit_by_code.value("p28").toString()); ui->txt_register_29->setText(q_Hs_search_for_edit_by_code.value("p29").toString());
            avatar_url = q_Hs_search_for_edit_by_code.value("p30").toString();
            QPixmap avatar_from_edit(avatar_url);   ui->lbl_register_avatar->setPixmap(avatar_url); ui->lbl_register_avatar->setScaledContents(true);

        }
        ui->txt_hs_search_for_edit_by_code->clear();    ui->txt_hs_search_for_edit_by_name->clear();    ui->txt_hs_search_for_edit_by_family->clear();
        if(ui->txt_register_0->text()=="" && ui->txt_register_1->text() =="" &&ui->txt_register_2->text()=="")
        {
            ui->groupBox_hs_register->hide(); ui->groupBox_hs_search_for_edit->show();
            ui->txt_hs_search_for_edit_by_code->clear();    ui->txt_hs_search_for_edit_by_name->clear();    ui->txt_hs_search_for_edit_by_family->clear();
            QMessageBox :: critical(this,"خطا",
                                       "کاربری با چنین کدملی یافت نشد\nجهت دقت بیشتر در جستجو ، از فیلد های بیشتری استفاده کنید");
        }
        else if(ui->txt_register_0->text()== "0" && ui->txt_register_1->text()== "1")
        {
            stats_check_code_user = true;
            ui->groupBox_hs_register->hide();   ui->groupBox_hs_search_for_edit->show();
            ui->txt_register_0->clear();  ui->txt_register_1->clear();  ui->txt_register_2->clear();  ui->txt_register_3->clear();  ui->txt_register_4->clear(); ui->txt_register_5->clear();  ui->txt_register_6->clear();   ui->txt_register_7->clear();  ui->txt_register_8->clear();  ui->txt_register_9->clear();  ui->txt_register_10->clear();  ui->txt_register_11->clear();  ui->txt_register_12->clear();   ui->txt_register_13->clear();   ui->txt_register_14->clear();  ui->txt_register_15->clear();  ui->txt_register_16->clear();  ui->txt_register_17->clear();  ui->txt_register_18->clear();  ui->txt_register_19->clear();  ui->txt_register_20->clear();  ui->txt_register_21->clear();  ui->txt_register_22->clear();   ui->txt_register_23->clear();   ui->txt_register_24->clear();   ui->txt_register_25->clear();  ui->txt_register_26->clear();  ui->txt_register_27->clear();  ui->txt_register_28->clear();  ui->txt_register_29->clear();   avatar_url = "";  ui->lbl_register_avatar->setPixmap(avatar_url);    ui->lbl_register_avatar->setScaledContents(true); ///root/Downloads/photo3983657131855423630.jpg
            ui->txt_hs_search_for_edit_by_family->clear();  ui->txt_hs_search_for_edit_by_name->clear();  ui->txt_hs_search_for_edit_by_code->clear();
            ui->txt_register_0->setDisabled(false); ui->txt_register_1->setDisabled(false);  ui->txt_register_2->setDisabled(false);
            ui->txt_register_0->setToolTip(""); ui->txt_register_1->setToolTip("");  ui->txt_register_2->setToolTip("");
            QMessageBox::critical(this,"خطا",
                                     "استفاده از کارکتر غیرمجاز\nلطفا از عداد برای پر کردن فیلد کدملی استفاده کنید !");
        }
    }
    else if(ui->txt_hs_search_for_edit_by_code->text() == "" && ui->txt_hs_search_for_edit_by_name->text() != "" && ui->txt_hs_search_for_edit_by_family->text() != "")
    {
        name = ui->txt_hs_search_for_edit_by_name->text();
        family = ui->txt_hs_search_for_edit_by_family->text();
        ui->groupBox_hs_search_for_edit->hide();
        edit_search_name_and_family = true;
        //editVar = &;  //editParameter = "p0";
        ui->txt_register_1->setDisabled(true);
        ui->txt_register_1->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو > کد ملی یا نام خالی یا نام خانوادگی خالی");
        ui->txt_register_2->setDisabled(true);
        ui->txt_register_2->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو > کد ملی ");
        ui->groupBox_hs_register->show();
        ui->groupBox_hs_register->setTitle("فرم ویرایش اعضای حسینیه");
        ui->btn_register_insert->setText("ویرایش");
        ui->btn_register_clear->setText("انصراف");

        QSqlQuery q_Hs_Load_Title("SELECT * FROM registrationTitles");
        while (q_Hs_Load_Title.next())
        {
            ui->lbl_register_t0->setText(q_Hs_Load_Title.value("t0").toString()); ui->lbl_register_t1->setText(q_Hs_Load_Title.value("t1").toString()); ui->lbl_register_t2->setText(q_Hs_Load_Title.value("t2").toString()); ui->lbl_register_t3->setText(q_Hs_Load_Title.value("t3").toString()); ui->lbl_register_t4->setText(q_Hs_Load_Title.value("t4").toString());                ui->lbl_register_t5->setText(q_Hs_Load_Title.value("t5").toString()); ui->lbl_register_t6->setText(q_Hs_Load_Title.value("t6").toString());               ui->lbl_register_t7->setText(q_Hs_Load_Title.value("t7").toString());  ui->lbl_register_t8->setText(q_Hs_Load_Title.value("t8").toString());              ui->lbl_register_t9->setText(q_Hs_Load_Title.value("t9").toString()); ui->lbl_register_t10->setText(q_Hs_Load_Title.value("t10").toString());                ui->lbl_register_t11->setText(q_Hs_Load_Title.value("t11").toString()); ui->lbl_register_t12->setText(q_Hs_Load_Title.value("t12").toString()); ui->lbl_register_t13->setText(q_Hs_Load_Title.value("t13").toString());                 ui->lbl_register_t14->setText(q_Hs_Load_Title.value("t14").toString()); ui->lbl_register_t15->setText(q_Hs_Load_Title.value("t15").toString());                ui->lbl_register_t16->setText(q_Hs_Load_Title.value("t16").toString());  ui->lbl_register_t17->setText(q_Hs_Load_Title.value("t17").toString()); ui->lbl_register_t18->setText(q_Hs_Load_Title.value("t18").toString());ui->lbl_register_t19->setText(q_Hs_Load_Title.value("t19").toString());ui->lbl_register_t20->setText(q_Hs_Load_Title.value("t20").toString());ui->lbl_register_t21->setText(q_Hs_Load_Title.value("t21").toString());ui->lbl_register_t22->setText(q_Hs_Load_Title.value("t22").toString());ui->lbl_register_t23->setText(q_Hs_Load_Title.value("t23").toString());ui->lbl_register_t24->setText(q_Hs_Load_Title.value("t24").toString());ui->lbl_register_t25->setText(q_Hs_Load_Title.value("t25").toString());ui->lbl_register_t26->setText(q_Hs_Load_Title.value("t26").toString()); ui->lbl_register_t27->setText(q_Hs_Load_Title.value("t27").toString());ui->lbl_register_t28->setText(q_Hs_Load_Title.value("t28").toString()); ui->lbl_register_t29->setText(q_Hs_Load_Title.value("t29").toString());
        }

        tmp1 = ui->txt_hs_search_for_edit_by_name->text();
        tmp2 = ui->txt_hs_search_for_edit_by_family->text();
        QSqlQuery q_Hs_search_for_edit_by_name_and_family("SELECT * FROM registration WHERE p1='"+tmp1+"' AND p2='"+tmp2+"'");
        while (q_Hs_search_for_edit_by_name_and_family.next())
        {
            ui->txt_register_0->setText(q_Hs_search_for_edit_by_name_and_family.value("p0").toString());    ui->txt_register_1->setText(q_Hs_search_for_edit_by_name_and_family.value("p1").toString());    ui->txt_register_2->setText(q_Hs_search_for_edit_by_name_and_family.value("p2").toString());    ui->txt_register_3->setText(q_Hs_search_for_edit_by_name_and_family.value("p3").toString());    ui->txt_register_4->setText(q_Hs_search_for_edit_by_name_and_family.value("p4").toString());    ui->txt_register_5->setText(q_Hs_search_for_edit_by_name_and_family.value("p5").toString());    ui->txt_register_6->setText(q_Hs_search_for_edit_by_name_and_family.value("p6").toString());    ui->txt_register_7->setText(q_Hs_search_for_edit_by_name_and_family.value("p7").toString());    ui->txt_register_8->setText(q_Hs_search_for_edit_by_name_and_family.value("p8").toString());    ui->txt_register_9->setText(q_Hs_search_for_edit_by_name_and_family.value("p9").toString());    ui->txt_register_10->setText(q_Hs_search_for_edit_by_name_and_family.value("p10").toString());  ui->txt_register_11->setText(q_Hs_search_for_edit_by_name_and_family.value("p11").toString());  ui->txt_register_12->setText(q_Hs_search_for_edit_by_name_and_family.value("p12").toString());  ui->txt_register_13->setText(q_Hs_search_for_edit_by_name_and_family.value("p13").toString());  ui->txt_register_14->setText(q_Hs_search_for_edit_by_name_and_family.value("p14").toString());  ui->txt_register_15->setText(q_Hs_search_for_edit_by_name_and_family.value("p15").toString());  ui->txt_register_16->setText(q_Hs_search_for_edit_by_name_and_family.value("p16").toString());  ui->txt_register_17->setText(q_Hs_search_for_edit_by_name_and_family.value("p17").toString());  ui->txt_register_18->setText(q_Hs_search_for_edit_by_name_and_family.value("p18").toString());  ui->txt_register_19->setText(q_Hs_search_for_edit_by_name_and_family.value("p19").toString());  ui->txt_register_20->setText(q_Hs_search_for_edit_by_name_and_family.value("p20").toString());  ui->txt_register_21->setText(q_Hs_search_for_edit_by_name_and_family.value("p21").toString());  ui->txt_register_22->setText(q_Hs_search_for_edit_by_name_and_family.value("p22").toString());  ui->txt_register_23->setText(q_Hs_search_for_edit_by_name_and_family.value("p23").toString());  ui->txt_register_24->setText(q_Hs_search_for_edit_by_name_and_family.value("p24").toString());  ui->txt_register_25->setText(q_Hs_search_for_edit_by_name_and_family.value("p25").toString());  ui->txt_register_26->setText(q_Hs_search_for_edit_by_name_and_family.value("p26").toString());  ui->txt_register_27->setText(q_Hs_search_for_edit_by_name_and_family.value("p27").toString());  ui->txt_register_28->setText(q_Hs_search_for_edit_by_name_and_family.value("p28").toString());  ui->txt_register_29->setText(q_Hs_search_for_edit_by_name_and_family.value("p29").toString());
            avatar_url = q_Hs_search_for_edit_by_name_and_family.value("p30").toString();
            QPixmap avatar_from_edit(avatar_url);   ui->lbl_register_avatar->setPixmap(avatar_url); ui->lbl_register_avatar->setScaledContents(true);
        }
        ui->txt_hs_search_for_edit_by_code->clear(); ui->txt_hs_search_for_edit_by_name->clear(); ui->txt_hs_search_for_edit_by_family->clear();
        if(ui->txt_register_0->text()=="" && ui->txt_register_1->text() =="" &&ui->txt_register_2->text()=="")
        {
            ui->groupBox_hs_register->hide();
            ui->groupBox_hs_search_for_edit->show();
            ui->txt_hs_search_for_edit_by_code->clear();    ui->txt_hs_search_for_edit_by_name->clear();    ui->txt_hs_search_for_edit_by_family->clear();
            QMessageBox :: critical(this,"خطا","کاربری با چنین نام و نام خانوادگی یافت نشد");
        }
    }
    else if(ui->txt_hs_search_for_edit_by_code->text() != "" && ui->txt_hs_search_for_edit_by_name->text() != "" && ui->txt_hs_search_for_edit_by_family->text() != "")
    {

        family = ui->txt_hs_search_for_edit_by_family->text();
        code= ui->txt_hs_search_for_edit_by_code->text();
        name = ui->txt_hs_search_for_edit_by_name->text();

        ui->groupBox_hs_search_for_edit->hide();
        edit_search_code_and_name_and_family = true;
        ui->txt_register_0->setDisabled(true);  ui->txt_register_1->setDisabled(true);  ui->txt_register_2->setDisabled(true);
        ui->txt_register_0->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو >   ");
        ui->txt_register_1->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو >   ");
        ui->txt_register_2->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو >   ");
        ui->groupBox_hs_register->show();
        ui->groupBox_hs_register->setTitle("فرم ویرایش اعضای حسینیه");
        ui->btn_register_insert->setText("ویرایش");
        ui->btn_register_clear->setText("انصراف");

        QSqlQuery q_Hs_Load_Title("SELECT * FROM registrationTitles");
        while (q_Hs_Load_Title.next())
        {
            ui->lbl_register_t0->setText(q_Hs_Load_Title.value("t0").toString()); ui->lbl_register_t1->setText(q_Hs_Load_Title.value("t1").toString()); ui->lbl_register_t2->setText(q_Hs_Load_Title.value("t2").toString()); ui->lbl_register_t3->setText(q_Hs_Load_Title.value("t3").toString()); ui->lbl_register_t4->setText(q_Hs_Load_Title.value("t4").toString());                ui->lbl_register_t5->setText(q_Hs_Load_Title.value("t5").toString()); ui->lbl_register_t6->setText(q_Hs_Load_Title.value("t6").toString());               ui->lbl_register_t7->setText(q_Hs_Load_Title.value("t7").toString());  ui->lbl_register_t8->setText(q_Hs_Load_Title.value("t8").toString());              ui->lbl_register_t9->setText(q_Hs_Load_Title.value("t9").toString()); ui->lbl_register_t10->setText(q_Hs_Load_Title.value("t10").toString());                ui->lbl_register_t11->setText(q_Hs_Load_Title.value("t11").toString()); ui->lbl_register_t12->setText(q_Hs_Load_Title.value("t12").toString()); ui->lbl_register_t13->setText(q_Hs_Load_Title.value("t13").toString());                 ui->lbl_register_t14->setText(q_Hs_Load_Title.value("t14").toString()); ui->lbl_register_t15->setText(q_Hs_Load_Title.value("t15").toString());                ui->lbl_register_t16->setText(q_Hs_Load_Title.value("t16").toString());  ui->lbl_register_t17->setText(q_Hs_Load_Title.value("t17").toString()); ui->lbl_register_t18->setText(q_Hs_Load_Title.value("t18").toString());ui->lbl_register_t19->setText(q_Hs_Load_Title.value("t19").toString());ui->lbl_register_t20->setText(q_Hs_Load_Title.value("t20").toString());ui->lbl_register_t21->setText(q_Hs_Load_Title.value("t21").toString());ui->lbl_register_t22->setText(q_Hs_Load_Title.value("t22").toString());ui->lbl_register_t23->setText(q_Hs_Load_Title.value("t23").toString());ui->lbl_register_t24->setText(q_Hs_Load_Title.value("t24").toString());ui->lbl_register_t25->setText(q_Hs_Load_Title.value("t25").toString());ui->lbl_register_t26->setText(q_Hs_Load_Title.value("t26").toString()); ui->lbl_register_t27->setText(q_Hs_Load_Title.value("t27").toString());ui->lbl_register_t28->setText(q_Hs_Load_Title.value("t28").toString()); ui->lbl_register_t29->setText(q_Hs_Load_Title.value("t29").toString());
        }

        tmp1 = ui->txt_hs_search_for_edit_by_name->text();
        tmp2 = ui->txt_hs_search_for_edit_by_family->text();
        tmp3 = ui->txt_hs_search_for_edit_by_code->text();
        QSqlQuery q_Hs_search_for_edit_by_code_and_name_and_family("SELECT * FROM registration WHERE p1='"+tmp1+"' AND p2='"+tmp2+"' AND p0='"+tmp3+"'");
        while (q_Hs_search_for_edit_by_code_and_name_and_family.next())
        {
            ui->txt_register_0->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p0").toString());    ui->txt_register_1->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p1").toString());    ui->txt_register_2->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p2").toString());    ui->txt_register_3->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p3").toString());    ui->txt_register_4->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p4").toString());    ui->txt_register_5->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p5").toString());    ui->txt_register_6->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p6").toString());    ui->txt_register_7->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p7").toString());    ui->txt_register_8->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p8").toString());    ui->txt_register_9->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p9").toString());    ui->txt_register_10->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p10").toString());  ui->txt_register_11->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p11").toString());  ui->txt_register_12->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p12").toString());  ui->txt_register_13->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p13").toString());  ui->txt_register_14->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p14").toString());  ui->txt_register_15->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p15").toString());  ui->txt_register_16->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p16").toString());  ui->txt_register_17->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p17").toString());  ui->txt_register_18->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p18").toString());  ui->txt_register_19->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p19").toString());  ui->txt_register_20->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p20").toString());  ui->txt_register_21->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p21").toString());  ui->txt_register_22->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p22").toString());  ui->txt_register_23->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p23").toString());  ui->txt_register_24->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p24").toString());  ui->txt_register_25->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p25").toString());  ui->txt_register_26->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p26").toString());  ui->txt_register_27->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p27").toString());  ui->txt_register_28->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p28").toString());  ui->txt_register_29->setText(q_Hs_search_for_edit_by_code_and_name_and_family.value("p29").toString());
            avatar_url = q_Hs_search_for_edit_by_code_and_name_and_family.value("p30").toString();
            QPixmap avatar_from_edit(avatar_url);   ui->lbl_register_avatar->setPixmap(avatar_url); ui->lbl_register_avatar->setScaledContents(true);
        }
        ui->txt_hs_search_for_edit_by_code->clear(); ui->txt_hs_search_for_edit_by_name->clear(); ui->txt_hs_search_for_edit_by_family->clear();
        if(ui->txt_register_0->text()=="" && ui->txt_register_1->text() =="" &&ui->txt_register_2->text()=="")
        {
            ui->groupBox_hs_register->hide();
            ui->groupBox_hs_search_for_edit->show();
            ui->txt_hs_search_for_edit_by_code->clear();    ui->txt_hs_search_for_edit_by_name->clear();    ui->txt_hs_search_for_edit_by_family->clear();
            QMessageBox :: critical(this,"خطا","کاربری با چنین نام و نام خانوادگی و کدملی یافت نشد");
        }
    }
    else if(ui->txt_hs_search_for_edit_by_code->text() != "" && ui->txt_hs_search_for_edit_by_name->text() != "" && ui->txt_hs_search_for_edit_by_family->text() == "")
    {
        //do
        name = ui->txt_hs_search_for_edit_by_name->text();
        code = ui->txt_hs_search_for_edit_by_code->text();
        ui->groupBox_hs_search_for_edit->hide();
        edit_search_code_and_name =true; //edit_search_name_and_family = true;
        ui->txt_register_0->setDisabled(true);  ui->txt_register_1->setDisabled(true);
        //ui->txt_register_1->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو > کد ملی ");
        ui->txt_register_0->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو > کد ملی یا نام خالی یا نام خانوادگی خالی");
        ui->txt_register_1->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو > کد ملی یا نام خالی یا نام خانوادگی خالی");
        ui->groupBox_hs_register->show();
        ui->groupBox_hs_register->setTitle("فرم ویرایش اعضای حسینیه");
        ui->btn_register_insert->setText("ویرایش");
        ui->btn_register_clear->setText("انصراف");

        QSqlQuery q_Hs_Load_Title("SELECT * FROM registrationTitles");
        while (q_Hs_Load_Title.next())
        {
            ui->lbl_register_t0->setText(q_Hs_Load_Title.value("t0").toString()); ui->lbl_register_t1->setText(q_Hs_Load_Title.value("t1").toString()); ui->lbl_register_t2->setText(q_Hs_Load_Title.value("t2").toString()); ui->lbl_register_t3->setText(q_Hs_Load_Title.value("t3").toString()); ui->lbl_register_t4->setText(q_Hs_Load_Title.value("t4").toString());                ui->lbl_register_t5->setText(q_Hs_Load_Title.value("t5").toString()); ui->lbl_register_t6->setText(q_Hs_Load_Title.value("t6").toString());               ui->lbl_register_t7->setText(q_Hs_Load_Title.value("t7").toString());  ui->lbl_register_t8->setText(q_Hs_Load_Title.value("t8").toString());              ui->lbl_register_t9->setText(q_Hs_Load_Title.value("t9").toString()); ui->lbl_register_t10->setText(q_Hs_Load_Title.value("t10").toString());                ui->lbl_register_t11->setText(q_Hs_Load_Title.value("t11").toString()); ui->lbl_register_t12->setText(q_Hs_Load_Title.value("t12").toString()); ui->lbl_register_t13->setText(q_Hs_Load_Title.value("t13").toString());                 ui->lbl_register_t14->setText(q_Hs_Load_Title.value("t14").toString()); ui->lbl_register_t15->setText(q_Hs_Load_Title.value("t15").toString());                ui->lbl_register_t16->setText(q_Hs_Load_Title.value("t16").toString());  ui->lbl_register_t17->setText(q_Hs_Load_Title.value("t17").toString()); ui->lbl_register_t18->setText(q_Hs_Load_Title.value("t18").toString());ui->lbl_register_t19->setText(q_Hs_Load_Title.value("t19").toString());ui->lbl_register_t20->setText(q_Hs_Load_Title.value("t20").toString());ui->lbl_register_t21->setText(q_Hs_Load_Title.value("t21").toString());ui->lbl_register_t22->setText(q_Hs_Load_Title.value("t22").toString());ui->lbl_register_t23->setText(q_Hs_Load_Title.value("t23").toString());ui->lbl_register_t24->setText(q_Hs_Load_Title.value("t24").toString());ui->lbl_register_t25->setText(q_Hs_Load_Title.value("t25").toString());ui->lbl_register_t26->setText(q_Hs_Load_Title.value("t26").toString()); ui->lbl_register_t27->setText(q_Hs_Load_Title.value("t27").toString());ui->lbl_register_t28->setText(q_Hs_Load_Title.value("t28").toString()); ui->lbl_register_t29->setText(q_Hs_Load_Title.value("t29").toString());
        }

        tmp1 = ui->txt_hs_search_for_edit_by_code->text();
        tmp2 = ui->txt_hs_search_for_edit_by_name->text();
        QSqlQuery q_Hs_search_for_edit_by_code_and_name("SELECT * FROM registration WHERE p0='"+tmp1+"' AND p1='"+tmp2+"'");
        while (q_Hs_search_for_edit_by_code_and_name.next())
        {
            ui->txt_register_0->setText(q_Hs_search_for_edit_by_code_and_name.value("p0").toString());    ui->txt_register_1->setText(q_Hs_search_for_edit_by_code_and_name.value("p1").toString());    ui->txt_register_2->setText(q_Hs_search_for_edit_by_code_and_name.value("p2").toString());    ui->txt_register_3->setText(q_Hs_search_for_edit_by_code_and_name.value("p3").toString());    ui->txt_register_4->setText(q_Hs_search_for_edit_by_code_and_name.value("p4").toString());    ui->txt_register_5->setText(q_Hs_search_for_edit_by_code_and_name.value("p5").toString());    ui->txt_register_6->setText(q_Hs_search_for_edit_by_code_and_name.value("p6").toString());    ui->txt_register_7->setText(q_Hs_search_for_edit_by_code_and_name.value("p7").toString());    ui->txt_register_8->setText(q_Hs_search_for_edit_by_code_and_name.value("p8").toString());    ui->txt_register_9->setText(q_Hs_search_for_edit_by_code_and_name.value("p9").toString());    ui->txt_register_10->setText(q_Hs_search_for_edit_by_code_and_name.value("p10").toString());  ui->txt_register_11->setText(q_Hs_search_for_edit_by_code_and_name.value("p11").toString());  ui->txt_register_12->setText(q_Hs_search_for_edit_by_code_and_name.value("p12").toString());  ui->txt_register_13->setText(q_Hs_search_for_edit_by_code_and_name.value("p13").toString());  ui->txt_register_14->setText(q_Hs_search_for_edit_by_code_and_name.value("p14").toString());  ui->txt_register_15->setText(q_Hs_search_for_edit_by_code_and_name.value("p15").toString());  ui->txt_register_16->setText(q_Hs_search_for_edit_by_code_and_name.value("p16").toString());  ui->txt_register_17->setText(q_Hs_search_for_edit_by_code_and_name.value("p17").toString());  ui->txt_register_18->setText(q_Hs_search_for_edit_by_code_and_name.value("p18").toString());  ui->txt_register_19->setText(q_Hs_search_for_edit_by_code_and_name.value("p19").toString());  ui->txt_register_20->setText(q_Hs_search_for_edit_by_code_and_name.value("p20").toString());  ui->txt_register_21->setText(q_Hs_search_for_edit_by_code_and_name.value("p21").toString());  ui->txt_register_22->setText(q_Hs_search_for_edit_by_code_and_name.value("p22").toString());  ui->txt_register_23->setText(q_Hs_search_for_edit_by_code_and_name.value("p23").toString());  ui->txt_register_24->setText(q_Hs_search_for_edit_by_code_and_name.value("p24").toString());  ui->txt_register_25->setText(q_Hs_search_for_edit_by_code_and_name.value("p25").toString());  ui->txt_register_26->setText(q_Hs_search_for_edit_by_code_and_name.value("p26").toString());  ui->txt_register_27->setText(q_Hs_search_for_edit_by_code_and_name.value("p27").toString());  ui->txt_register_28->setText(q_Hs_search_for_edit_by_code_and_name.value("p28").toString());  ui->txt_register_29->setText(q_Hs_search_for_edit_by_code_and_name.value("p29").toString());
            avatar_url = q_Hs_search_for_edit_by_code_and_name.value("p30").toString();
            QPixmap avatar_from_edit(avatar_url);   ui->lbl_register_avatar->setPixmap(avatar_url); ui->lbl_register_avatar->setScaledContents(true);
        }
        ui->txt_hs_search_for_edit_by_code->clear(); ui->txt_hs_search_for_edit_by_name->clear(); ui->txt_hs_search_for_edit_by_family->clear();
        if(ui->txt_register_0->text()=="" && ui->txt_register_1->text() =="" &&ui->txt_register_2->text()=="")
        {
            ui->groupBox_hs_register->hide();
            ui->groupBox_hs_search_for_edit->show();
            ui->txt_hs_search_for_edit_by_code->clear();    ui->txt_hs_search_for_edit_by_name->clear();    ui->txt_hs_search_for_edit_by_family->clear();
            QMessageBox :: critical(this,"خطا","کاربری با چنین نام و کدملی یافت نشد");
        }
    }
    else if(ui->txt_hs_search_for_edit_by_code->text() != "" && ui->txt_hs_search_for_edit_by_name->text() == "" && ui->txt_hs_search_for_edit_by_family->text() != "")
    {
        family = ui->txt_hs_search_for_edit_by_family->text();
        code = ui->txt_hs_search_for_edit_by_code->text();
        ui->groupBox_hs_search_for_edit->hide();
        edit_search_code_and_family =true;
        ui->txt_register_0->setDisabled(true);  ui->txt_register_2->setDisabled(true);
        ui->txt_register_0->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو > کد ملی یا نام خالی یا نام خانوادگی خالی");
        ui->txt_register_2->setToolTip("نمی توانید فیلد شرط را تغییر دهید برای ویرایش این فیلد از روش جستجوی دیگری استفاده کنید \nراهنما :‌   جستجو در حسینیه >‌ روش جستجو > کد ملی یا نام خالی یا نام خانوادگی خالی");
        ui->groupBox_hs_register->show();
        ui->groupBox_hs_register->setTitle("فرم ویرایش اعضای حسینیه");
        ui->btn_register_insert->setText("ویرایش");
        ui->btn_register_clear->setText("انصراف");

        QSqlQuery q_Hs_Load_Title("SELECT * FROM registrationTitles");
        while (q_Hs_Load_Title.next())
        {
            ui->lbl_register_t0->setText(q_Hs_Load_Title.value("t0").toString()); ui->lbl_register_t1->setText(q_Hs_Load_Title.value("t1").toString()); ui->lbl_register_t2->setText(q_Hs_Load_Title.value("t2").toString()); ui->lbl_register_t3->setText(q_Hs_Load_Title.value("t3").toString()); ui->lbl_register_t4->setText(q_Hs_Load_Title.value("t4").toString());                ui->lbl_register_t5->setText(q_Hs_Load_Title.value("t5").toString()); ui->lbl_register_t6->setText(q_Hs_Load_Title.value("t6").toString());               ui->lbl_register_t7->setText(q_Hs_Load_Title.value("t7").toString());  ui->lbl_register_t8->setText(q_Hs_Load_Title.value("t8").toString());              ui->lbl_register_t9->setText(q_Hs_Load_Title.value("t9").toString()); ui->lbl_register_t10->setText(q_Hs_Load_Title.value("t10").toString());                ui->lbl_register_t11->setText(q_Hs_Load_Title.value("t11").toString()); ui->lbl_register_t12->setText(q_Hs_Load_Title.value("t12").toString()); ui->lbl_register_t13->setText(q_Hs_Load_Title.value("t13").toString());                 ui->lbl_register_t14->setText(q_Hs_Load_Title.value("t14").toString()); ui->lbl_register_t15->setText(q_Hs_Load_Title.value("t15").toString());                ui->lbl_register_t16->setText(q_Hs_Load_Title.value("t16").toString());  ui->lbl_register_t17->setText(q_Hs_Load_Title.value("t17").toString()); ui->lbl_register_t18->setText(q_Hs_Load_Title.value("t18").toString());ui->lbl_register_t19->setText(q_Hs_Load_Title.value("t19").toString());ui->lbl_register_t20->setText(q_Hs_Load_Title.value("t20").toString());ui->lbl_register_t21->setText(q_Hs_Load_Title.value("t21").toString());ui->lbl_register_t22->setText(q_Hs_Load_Title.value("t22").toString());ui->lbl_register_t23->setText(q_Hs_Load_Title.value("t23").toString());ui->lbl_register_t24->setText(q_Hs_Load_Title.value("t24").toString());ui->lbl_register_t25->setText(q_Hs_Load_Title.value("t25").toString());ui->lbl_register_t26->setText(q_Hs_Load_Title.value("t26").toString()); ui->lbl_register_t27->setText(q_Hs_Load_Title.value("t27").toString());ui->lbl_register_t28->setText(q_Hs_Load_Title.value("t28").toString()); ui->lbl_register_t29->setText(q_Hs_Load_Title.value("t29").toString());
        }

        tmp1 = ui->txt_hs_search_for_edit_by_code->text();
        tmp2 = ui->txt_hs_search_for_edit_by_family->text();
        QSqlQuery q_Hs_search_for_edit_by_code_and_family("SELECT * FROM registration WHERE p0='"+tmp1+"' AND p2='"+tmp2+"'");
        while (q_Hs_search_for_edit_by_code_and_family.next())
        {
            ui->txt_register_0->setText(q_Hs_search_for_edit_by_code_and_family.value("p0").toString());    ui->txt_register_1->setText(q_Hs_search_for_edit_by_code_and_family.value("p1").toString());    ui->txt_register_2->setText(q_Hs_search_for_edit_by_code_and_family.value("p2").toString());    ui->txt_register_3->setText(q_Hs_search_for_edit_by_code_and_family.value("p3").toString());    ui->txt_register_4->setText(q_Hs_search_for_edit_by_code_and_family.value("p4").toString());    ui->txt_register_5->setText(q_Hs_search_for_edit_by_code_and_family.value("p5").toString());    ui->txt_register_6->setText(q_Hs_search_for_edit_by_code_and_family.value("p6").toString());    ui->txt_register_7->setText(q_Hs_search_for_edit_by_code_and_family.value("p7").toString());    ui->txt_register_8->setText(q_Hs_search_for_edit_by_code_and_family.value("p8").toString());    ui->txt_register_9->setText(q_Hs_search_for_edit_by_code_and_family.value("p9").toString());    ui->txt_register_10->setText(q_Hs_search_for_edit_by_code_and_family.value("p10").toString());  ui->txt_register_11->setText(q_Hs_search_for_edit_by_code_and_family.value("p11").toString());  ui->txt_register_12->setText(q_Hs_search_for_edit_by_code_and_family.value("p12").toString());  ui->txt_register_13->setText(q_Hs_search_for_edit_by_code_and_family.value("p13").toString());  ui->txt_register_14->setText(q_Hs_search_for_edit_by_code_and_family.value("p14").toString());  ui->txt_register_15->setText(q_Hs_search_for_edit_by_code_and_family.value("p15").toString());  ui->txt_register_16->setText(q_Hs_search_for_edit_by_code_and_family.value("p16").toString());  ui->txt_register_17->setText(q_Hs_search_for_edit_by_code_and_family.value("p17").toString());  ui->txt_register_18->setText(q_Hs_search_for_edit_by_code_and_family.value("p18").toString());  ui->txt_register_19->setText(q_Hs_search_for_edit_by_code_and_family.value("p19").toString());  ui->txt_register_20->setText(q_Hs_search_for_edit_by_code_and_family.value("p20").toString());  ui->txt_register_21->setText(q_Hs_search_for_edit_by_code_and_family.value("p21").toString());  ui->txt_register_22->setText(q_Hs_search_for_edit_by_code_and_family.value("p22").toString());  ui->txt_register_23->setText(q_Hs_search_for_edit_by_code_and_family.value("p23").toString());  ui->txt_register_24->setText(q_Hs_search_for_edit_by_code_and_family.value("p24").toString());  ui->txt_register_25->setText(q_Hs_search_for_edit_by_code_and_family.value("p25").toString());  ui->txt_register_26->setText(q_Hs_search_for_edit_by_code_and_family.value("p26").toString());  ui->txt_register_27->setText(q_Hs_search_for_edit_by_code_and_family.value("p27").toString());  ui->txt_register_28->setText(q_Hs_search_for_edit_by_code_and_family.value("p28").toString());  ui->txt_register_29->setText(q_Hs_search_for_edit_by_code_and_family.value("p29").toString());
            avatar_url = q_Hs_search_for_edit_by_code_and_family.value("p30").toString();
            QPixmap avatar_from_edit(avatar_url);   ui->lbl_register_avatar->setPixmap(avatar_url); ui->lbl_register_avatar->setScaledContents(true);
        }
        ui->txt_hs_search_for_edit_by_code->clear(); ui->txt_hs_search_for_edit_by_name->clear(); ui->txt_hs_search_for_edit_by_family->clear();
        if(ui->txt_register_0->text()=="" && ui->txt_register_1->text() =="" &&ui->txt_register_2->text()=="")
        {
            ui->groupBox_hs_register->hide();
            ui->groupBox_hs_search_for_edit->show();
            ui->txt_hs_search_for_edit_by_code->clear();    ui->txt_hs_search_for_edit_by_name->clear();    ui->txt_hs_search_for_edit_by_family->clear();
            QMessageBox :: critical(this,"خطا","کاربری با چنین کدملی و نام خانوادگی یافت نشد");
        }
    }
}

void MainWindow::on_btn_register_avatar_clicked()
{
    QMessageBox::information(this,"راهنما",
                             "برای جلوگیری از هرگونه تداخل در باگیری تصویر  \nتوجه داشته باشید که تصویر مورد نظر در یک فایل ثابت(ایمن) ذخیر کرده باشید. ");
    QString url_and_filename_avatar = QFileDialog::getOpenFileName(this, "تصویر مورد نظر را انتخاب کنید" , "/home");
    QPixmap pm(url_and_filename_avatar); ui->lbl_register_avatar->setPixmap(url_and_filename_avatar); ui->lbl_register_avatar->setScaledContents(true);
    avatar_url = url_and_filename_avatar;
}

void MainWindow::on_btn_login_clicked()
{
    int current_try;
    int max_try;
    //login varaibels
    QSqlQuery q_Hs_login_give_maxtry_and_currenttry("SELECT * FROM adminconfig;");
    while (q_Hs_login_give_maxtry_and_currenttry.next())
    {
        max_try = q_Hs_login_give_maxtry_and_currenttry.value("maxtry").toInt();
        current_try = q_Hs_login_give_maxtry_and_currenttry.value("currenttry").toInt();
    }

    QSqlQuery q_Hs_login("SELECT username,password FROM adminconfig;");
    while (q_Hs_login.next())
    {
        const QString username = q_Hs_login.value("username").toString();
        const QString password = q_Hs_login.value("password").toString();//HASH
        int tottalAdminLogins;
        QString totall_tmp ="";

        if(ui->txt_username->text() == username && ui->txt_password->text() == password)
        {
            if(current_try>=max_try)
            {
                QMessageBox::critical(this, "مسدودیت حساب!",
                                      "<FONT COLOR='#000000'>به علت تعداد تلاش مکرر در ورود ، حساب کاربری شما مسدود شده است.  </FONT><FONT COLOR='#ff0000'>("+QString::number(max_try)+"/"+QString::number(current_try)+")</FONT>");
            }
            else
            {
                //message or actions for user
                QMessageBox::information(this," .خوش‌ آمدید "+username,
                                         "ورود با موفیقت انجام شد");
               ui->menubar->setDisabled(false); //or hide
                ui->groupBox_login->hide();



                //update and give last login number for create next field to table adminloginslog
                QSqlQuery give_total_logins("SELECT total_logins FROM adminconfig");
                while (give_total_logins.next())
                {
                     totall_tmp = give_total_logins.value("total_logins").toString();
                }
                tottalAdminLogins = totall_tmp.toInt();
                if(tottalAdminLogins>=1000)
                {
                    //delete Table  and create again..
                    QSqlQuery drop_table_adminloginslog("DROP TABLE adminloginslog;");

                    //create again
                    QSqlQuery add_table_adminloginslog("CREATE TABLE adminloginslog(login_number VARCHAR(1000), login_date VARCHAR(80));");
                    QSqlQuery add_Default_value_to_adminsloginlog("INSERT INTO adminloginslog (login_number,login_date) VALUES ('login_0','unknow-date');");
                    QSqlQuery update_total_logins("UPDATE adminconfig SET total_logins='0';");
                    QMessageBox::warning(this,"توجه",
                                             "تعداد ورود های ادمین ثبت شده بیشتر از ۱۰۰۰ عدد شده و تعداد ورودهای ثبت شده از اول راه اندازی شدند.");

                }
                else
                {
                    tottalAdminLogins++;
                    QSqlQuery update_total_logins("UPDATE adminconfig SET total_logins='"+QString::number(tottalAdminLogins)+"';");
                    //give current date and insert to table adminloginslog
                    QString currentTimeAndDate =  QDateTime::currentDateTime().toString();

                    QSqlQuery add_new_login_date_to_loginslog("INSERT INTO adminloginslog (login_number,login_date) VALUES ('login_"+QString::number(+tottalAdminLogins)+"','"+currentTimeAndDate+"');");
                    //tottalAdminLogins=0; //currentTimeAndDate=""; //totall_tmp="";
                }
            }

        }
        else
        {
            if(current_try>=max_try)
            {
                QMessageBox::critical(this, "مسدودیت حساب!",
                                      "<FONT COLOR='#000000'>به علت تعداد تلاش مکرر در ورود ، حساب کاربری شما مسدود شده است.  </FONT><FONT COLOR='#ff0000'>("+QString::number(max_try)+"/"+QString::number(current_try)+")</FONT>");
            }
            else
            {
                current_try++;
                QSqlQuery q_Hs_login_append_currenttry("UPDATE adminconfig SET currenttry='"+QString::number(current_try)+"';");
                QMessageBox::warning(this, "عدم موفقیت در ورود به حساب کاربری",
                                     "<FONT COLOR='#000000'>نام کاربری یا کلمه عبور اشتباه است تعداد دفعات باقیمانده تلاش برای ورود</FONT>  <FONT COLOR='#ff0000'>("+QString::number(max_try)+"/"+QString::number(current_try)+")</FONT>");
            }

        }
    }
}
